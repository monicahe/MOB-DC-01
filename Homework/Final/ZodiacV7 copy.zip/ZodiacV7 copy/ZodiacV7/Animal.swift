//
//  Animal.swift
//  ZodiacV7
//
//  Created by Monica He on 3/24/15.
//  Copyright (c) 2015 Monica He. All rights reserved.
//

import Foundation

struct Animal {
    var name = ""
    var rank = ""
    var character = ""
    var image = ""
}

